Стрелки — Android WebView оболочка

В app/src/main/assets/index.html находится исходный arrows2.html без изменения игровой логики.
Приложение открывает его локально внутри WebView. JavaScript и DOM Storage включены,
поэтому настройки/прогресс, которые HTML сохраняет через localStorage, остаются на устройстве.

Сборка: загрузить содержимое ZIP в GitHub-репозиторий и добавить workflow из отдельного файла.
